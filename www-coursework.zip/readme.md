Tampere University - WWW Programming 2019 - Coursework (5 ECTS)

A simple user role management system made using Express and Handlebars.
Contains a simple REST API and authentication with json web tokens with custom permission/role system.